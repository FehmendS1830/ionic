export interface Continent {
    id: number;
    name: string;
}