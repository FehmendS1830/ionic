import { DetailResolver } from './detail-resolver';

describe('DetailResolver', () => {
  it('should create an instance', () => {
    expect(new DetailResolver()).toBeTruthy();
  });
});
