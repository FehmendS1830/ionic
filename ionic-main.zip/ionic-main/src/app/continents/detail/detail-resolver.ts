export class DetailResolver {
}
