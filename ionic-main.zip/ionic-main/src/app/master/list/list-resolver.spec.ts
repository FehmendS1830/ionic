import { ListResolver } from './list-resolver';

describe('ListResolver', () => { /*
  it('should create an instance', () => {
    expect(new ListResolver()).toBeTruthy();
  });*/
});
