import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-resolver',
  templateUrl: './list-resolver.component.html',
  styleUrls: ['./list-resolver.component.scss'],
})
export class ListResolverComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
